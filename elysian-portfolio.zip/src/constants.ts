import { Code2, Globe, Database, Brain, Terminal, Github, Linkedin, Mail, Download, ExternalLink } from 'lucide-react';

export const PERSONAL_INFO = {
  name: "Zulfiqar Ali Bhutto",
  tagline: "Computer Engineering Student | Researcher | Developer",
  intro: "A Computer Engineering student passionate about software development, machine learning, and research. I am dedicated to continuously improving my skills and building impactful modern technology solutions.",
  bio: "Zulfiqar Ali Bhutto is a Computer Engineering student who is deeply interested in software development, machine learning, and research. He is continuously improving his programming skills and working on practical projects related to modern technology. He thrives on solving complex technical challenges and contributing to the global research community.",
  education: [
    {
      degree: "B.E. in Computer Engineering",
      institution: "Quest Nawabshah",
      period: "2022- 2026",
      description: "Specializing in software systems, AI integration, and engineering research."
    }
  ],
  careerObjective: "To explore the intersections of machine learning and software engineering while contributing to innovative research that solves real-world problems.",
  socials: [
    { icon: Github, href: "https://github.com/zulfiqaralibhutto", label: "GitHub" },
    { icon: Linkedin, href: "https://linkedin.com/in/mirzulfiqarbhutto", label: "LinkedIn" },
    { icon: Mail, href: "mailto:mirzulfiqarb@gmail.com", label: "Email" }
  ]
};

export const SKILLS = [
  { 
    category: "Languages",
    items: [
      { name: "C++", level: 90, icon: Terminal },
      { name: "Python", level: 95, icon: Brain },
      { name: "JavaScript", level: 85, icon: Globe }
    ]
  },
  { 
    category: "Tools & Tech",
    items: [
      { name: "Git", level: 90, icon: Code2 },
      { name: "VS Code", level: 95, icon: Code2 },
      { name: "Packet Tracer", level: 80, icon: Database }
    ]
  },
  { 
    category: "Specializations",
    items: [
      { name: "Machine Learning", level: 85, icon: Brain },
      { name: "Web Development", level: 90, icon: Globe },
      { name: "Data Analysis", level: 80, icon: Database }
    ]
  }
];

export const PROJECTS = [
  {
    title: "Neural Vision Assistant",
    description: "An AI-powered computer vision tool designed to assist visually impaired individuals by identifying objects in real-time using mobile cameras.",
    tech: ["Python", "TensorFlow", "React Native"],
    github: "https://github.com",
    demo: "https://example.com",
    image: "https://images.unsplash.com/photo-1555255707-c07966488bc0?auto=format&fit=crop&q=80&w=800"
  },
  {
    title: "EcoGrid Smart Manager",
    description: "A smart grid monitoring system that optimizes energy distribution in small-scale renewable energy communities using IoT sensors.",
    tech: ["C++", "Arduino", "Node.js"],
    github: "https://github.com",
    demo: "https://example.com",
    image: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&q=80&w=800"
  },
  {
    title: "Quantum Ledger",
    description: "A decentralized voting application prototype built to ensure transparency and security in student government elections.",
    tech: ["Solidity", "Ether.js", "Next.js"],
    github: "https://github.com",
    demo: "https://example.com",
    image: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=800"
  }
];

export const SERVICES = [
  {
    title: "Web Development",
    description: "Building responsive, modern web applications with a focus on performance and clean UX.",
    icon: Globe
  },
  {
    title: "Technical Tutoring",
    description: "Passionate about simplifying complex concepts in Data Structures, Algorithms, and Python.",
    icon: Terminal
  },
  {
    title: "Research Assistance",
    description: "Experienced in literature reviews and data analysis for AI and hardware engineering projects.",
    icon: Brain
  }
];
